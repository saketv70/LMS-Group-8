package com.lms.query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
